import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-loan-row',
  templateUrl: './dashboard-loan-row.component.html',
  styleUrls: ['./dashboard-loan-row.component.css']
})
export class DashboardLoanRowComponent implements OnInit {
  @Input() loan: any = {};
  constructor() { }

  ngOnInit(): void {
  }

}
