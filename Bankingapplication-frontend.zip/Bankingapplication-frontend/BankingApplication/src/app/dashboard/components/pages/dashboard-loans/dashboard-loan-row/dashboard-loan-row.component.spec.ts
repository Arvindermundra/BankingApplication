import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardLoanRowComponent } from './dashboard-loan-row.component';

describe('DashboardLoanRowComponent', () => {
  let component: DashboardLoanRowComponent;
  let fixture: ComponentFixture<DashboardLoanRowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashboardLoanRowComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DashboardLoanRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
