import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-action',
  templateUrl: './dashboard-action.component.html',
  styleUrls: ['./dashboard-action.component.css']
})
export class DashboardActionComponent implements OnInit {

  userDetails: any = {};
  admin: boolean = false;

  ngOnInit(): void {
    this.userDetails = JSON.parse(localStorage.getItem('userDetails') || '');
    
    if (this.userDetails.roles.includes('ROLE_ADMIN')) {
      this.admin = true;
    }
  }
}
