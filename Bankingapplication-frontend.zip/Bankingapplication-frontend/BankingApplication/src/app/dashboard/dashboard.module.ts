import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './components/pages/dashboard/dashboard.component';
import { DashboardActionComponent } from './components/pages/dashboard-action/dashboard-action.component';
import { DashboardLoansComponent } from './components/pages/dashboard-loans/dashboard-loans.component';
import { DashboardLoanRowComponent } from './components/pages/dashboard-loans/dashboard-loan-row/dashboard-loan-row.component';
import { HttpClientModule } from '@angular/common/http';
import { httpInterceptors } from '../shared/interceptors';
import { LoanService } from '../loan/services/loan.service';
import { AccountService } from '../account/services/account.service';


@NgModule({
  declarations: [
    DashboardComponent,
    DashboardActionComponent,
    DashboardLoansComponent,
    DashboardLoanRowComponent,
  ],
  imports: [CommonModule, HttpClientModule, DashboardModule],
  providers: [AccountService, LoanService, httpInterceptors],
})
export class DashboardModule {}