import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IAccount } from 'src/app/account/models/iaccount';
import { AccountService } from 'src/app/account/services/account.service';


@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {
  account: IAccount = {
    accountType: '',
    panNumber: '',
    aadharNumber: '',
    contact: '',
    balance: 0,
    userId: 0,
  };
  constructor(private accountService: AccountService, private router: Router) {}

  ngOnInit(): void {}

  createAccount() {
    this.account.userId = JSON.parse(
      localStorage.getItem('userDetails') || ''
    ).id;

    console.log(this.account);
    this.accountService.createAccount(this.account).subscribe(
      (res) => {
        //rest call
        console.log(res);
        localStorage.setItem('accountDetails', JSON.stringify(res));
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
