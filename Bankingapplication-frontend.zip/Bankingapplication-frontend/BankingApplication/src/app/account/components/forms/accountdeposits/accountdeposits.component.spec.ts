import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountdepositsComponent } from './accountdeposits.component';

describe('AccountdepositsComponent', () => {
  let component: AccountdepositsComponent;
  let fixture: ComponentFixture<AccountdepositsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountdepositsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccountdepositsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
