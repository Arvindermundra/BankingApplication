import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountwithdrawalComponent } from './accountwithdrawal.component';

describe('AccountwithdrawalComponent', () => {
  let component: AccountwithdrawalComponent;
  let fixture: ComponentFixture<AccountwithdrawalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountwithdrawalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccountwithdrawalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
