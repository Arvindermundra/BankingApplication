import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from 'src/app/account/services/account.service';


@Component({
  selector: 'app-accountwithdrawal',
  templateUrl: './accountwithdrawal.component.html',
  styleUrls: ['./accountwithdrawal.component.css']
})
export class AccountwithdrawalComponent implements OnInit {

  amount: number = 0;
  errorMessage: string = '';
  constructor(private accountService: AccountService, private router: Router) {}

  ngOnInit(): void {
  }
  withdrawAmount() {
    let accountId = JSON.parse(
      localStorage.getItem('accountDetails') || ''
    ).accountId;

    this.accountService.depositAmount(accountId, this.amount).subscribe(
      (res) => {
        console.log(res);
        localStorage.setItem('accountDetails', JSON.stringify(res));
        this.amount = 0;
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        this.errorMessage = err.errors.message;
        console.log(err);
      }
    );
  }

}
