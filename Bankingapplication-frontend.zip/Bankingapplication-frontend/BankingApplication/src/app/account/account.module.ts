import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountwithdrawalComponent } from './components/forms/accountwithdrawal/accountwithdrawal.component';
import { AccountdepositsComponent } from './components/forms/accountdeposits/accountdeposits.component';
import { CreateaccountComponent } from './components/forms/createaccount/createaccount.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AccountService } from './services/account.service';
import { httpInterceptors } from '../shared/interceptors';
import { AccountRoutingModule } from './account-routing.module';

@NgModule({
  declarations: [
    AccountwithdrawalComponent,
    AccountdepositsComponent,
    CreateaccountComponent
  ],
  imports: [CommonModule, FormsModule, HttpClientModule, AccountRoutingModule],
  providers: [AccountService, httpInterceptors],
})
export class AccountModule { }
