import { Injectable } from '@angular/core';
import { IAccount} from '../models/iaccount';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';


const headerData = {
  headers: { 'Content-Type': 'application/json' },
};
@Injectable({
  providedIn: 'root'
})
export class AccountService {

    constructor(private httpClient: HttpClient) {}
  
    endPoint: string = '/api/account';
  
    createAccount(account: IAccount): Observable<any> {
      return this.httpClient.post(
        this.endPoint + '/create',
        account,
        headerData
      );
    }

    getAccount(userId: number): Observable<any> {
      return this.httpClient.get(this.endPoint + '/user/' + userId);
    }

    depositAmount(accountId: string, amount: number): Observable<any> {
      return this.httpClient.post(
        this.endPoint + '/deposit/' + accountId,
        { amount: amount },
        headerData
      );
    }
  
    withdrawAmount(accountId: string, amount: number): Observable<any> {
      return this.httpClient.post(
        this.endPoint + '/withdraw/' + accountId,
        { amount: amount },
        headerData
      );
    }
  
    closeAccount(accountId: string): Observable<any> {
      return this.httpClient.post(
        this.endPoint + '/close/' + accountId,
        {},
        headerData
      );
    }
  
}
