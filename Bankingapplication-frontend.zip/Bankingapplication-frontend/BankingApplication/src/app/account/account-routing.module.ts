import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountwithdrawalComponent } from './components/forms/accountwithdrawal/accountwithdrawal.component';
import { AccountdepositsComponent } from './components/forms/accountdeposits/accountdeposits.component';
import { CreateaccountComponent } from './components/forms/createaccount/createaccount.component';
const routes: Routes = [
  { path: 'create-account', component:  AccountwithdrawalComponent  },
  { path: 'account-deposit', component:  AccountdepositsComponent },
  { path: 'account-withdraw', component: CreateaccountComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AccountRoutingModule {}
