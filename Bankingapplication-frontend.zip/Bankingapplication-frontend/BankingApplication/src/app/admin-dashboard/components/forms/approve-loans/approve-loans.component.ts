import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approve-loans',
  templateUrl: './approve-loans.component.html',
  styleUrls: ['./approve-loans.component.css']
})
export class ApproveLoansComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
