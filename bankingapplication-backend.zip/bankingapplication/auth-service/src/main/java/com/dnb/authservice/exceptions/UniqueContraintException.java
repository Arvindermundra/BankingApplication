package com.dnb.authservice.exceptions;

public class UniqueContraintException extends Exception {

	private static final long serialVersionUID = 1L;

	public UniqueContraintException(String message) {
		super(message);
	}

}
