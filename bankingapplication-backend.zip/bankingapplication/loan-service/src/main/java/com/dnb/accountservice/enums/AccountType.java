package com.dnb.accountservice.enums;

public enum AccountType {
	SAVINGS, CURRENT
}
