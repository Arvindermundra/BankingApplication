package com.dnb.loanservice.controller;

import java.util.Optional;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dnb.loanservice.dto.Loan;
import com.dnb.loanservice.exceptions.IdNotFoundException;
import com.dnb.loanservice.mapper.EntityToResponseMapper;
import com.dnb.loanservice.mapper.RequestToEntityMapper;
import com.dnb.loanservice.request.payload.LoanRequest;
import com.dnb.loanservice.service.LoanService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/loan")
@CrossOrigin("*")
public class LoanController {

	@Autowired
	LoanService loanService;

	@Autowired
	private RequestToEntityMapper requestToEntityMapper;

	@Autowired
	private EntityToResponseMapper entityToResponseMapper;
	
	@PostMapping("/create")
	public ResponseEntity<?> createloan(@Valid @RequestBody LoanRequest loanRequest){
		Loan loan = requestToEntityMapper.getLoanEntityObject(loanRequest);
		try {
			Loan loan2 = loanService.createLoan(loan);
			return new ResponseEntity(loan2,HttpStatus.CREATED);
		}
		catch(IdNotFoundException e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}
	
	@GetMapping("/account/{loanId}")
	public ResponseEntity<?>getloanById(@PathVariable("loanId")String loanId) throws IdNotFoundException{
		Optional<Loan>optional = loanService.getLoan(loanId);
		if(optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new IdNotFoundException("Id not found");
		}
	}
	
	@GetMapping("/all")
	public ResponseEntity<?>getAllloans(Boolean status) throws IdNotFoundException{
		List<Loan>loans=(List<Loan>) loanService.getLoans();
		if(loans.isEmpty()) {
			throw new IdNotFoundException("Id not found");
		}
		else {
			return ResponseEntity.ok(loans);
		}
	}
	
	@PutMapping("/approve/{loanId}")
	public ResponseEntity<?> changeLoanStatus(@PathVariable("loanId") String loadId) throws IdNotFoundException {
		
		Loan loan = loanService.approveLoan(loadId);

		return ResponseEntity.ok(loan);
	}

	@DeleteMapping("/{loanId}")
	public ResponseEntity<?> deleteLoanById(@PathVariable("loanId") String loanId) throws IdNotFoundException {

		loanService.deleteLoanById(loanId);
		return ResponseEntity.noContent().build();
	}

	
	
	
	
}
