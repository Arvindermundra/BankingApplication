package com.dnb.loanservice.mapper;

import org.springframework.stereotype.Component;

import com.dnb.loanservice.dto.Loan;
import com.dnb.loanservice.response.payload.LoanResponse;

@Component
public class EntityToResponseMapper {

	public Loan loanToAccountResponse(LoanResponse loanResponse) {

		Loan loan = new Loan();
		
		loan.setAccountId(loanResponse.getAccountId());
		loan.setAmount(loanResponse.getAmount());
		loan.setLoanId(loanResponse.getLoanId());
		loan.setStatus(loanResponse.isStatus());
		loan.setLoanType(loanResponse.getLoanType());
		
		return loan;
	}
}
