package com.dnb.loanservice.dto;

import com.dnb.accountservice.enums.AccountType;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class Account {

	private String accountId;
	private Integer userId;
	private AccountType accountType;
	private String panNumber;
	private String aadharNumber;
	private String mobileNumber;
	private Boolean accountStatus;
	private long balance;
}