package com.dnb.accountservice.payload.response;

import com.dnb.accountservice.enums.AccountType;

import lombok.Data;

@Data
public class AccountResponse {
	private String accountId;
	private Integer userId;
	private AccountType accountType;
	private String panNumber;
	private String aadharNumber;
	private String mobileNumber;
	private Boolean accountStatus;
	private long balance;

}
