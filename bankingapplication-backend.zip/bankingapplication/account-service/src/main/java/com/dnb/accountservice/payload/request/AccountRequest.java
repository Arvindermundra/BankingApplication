package com.dnb.accountservice.payload.request;


import com.dnb.accountservice.enums.AccountType;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AccountRequest {
	
	@NotNull
	private Integer userId;
	
	@NotNull(message = "Please select the account type")
	private AccountType accountType;
	@NotBlank(message = "Pan Number cannot be blank")
	private String panNumber;
	@NotBlank(message = "Aadhaar Number cannot be blank")
	private String aadharNumber;
	
	@NotBlank(message = "Mobile Number cannot be blank")
	private String mobileNumber;
	private Boolean accountStatus;
	@Min(value=10000)
	private long balance;
}
