package com.dnb.accountservice.dto;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dnb.accountservice.enums.AccountType;
import com.dnb.accountservice.utils.CustomIdGenerator;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
public class Account {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "account_seq")
	@GenericGenerator(name="account_seq",strategy="com.dnb.accountservice.utils.CustomIdGenerator",
	parameters =  {@Parameter(name=CustomIdGenerator.INCREMENT_PARAM,value="50"),
			@Parameter(name=CustomIdGenerator.VALUE_PREFIX_PARAMETER,value="Acc_"),
			@Parameter(name=CustomIdGenerator.NUMBER_FORMAT_PARAMETER,value="%05d")}
			)
	private String accountId;
	private Integer userId;
	
	@NotNull(message = "Please select the account type")
	private AccountType accountType;
	@NotBlank(message = "Pan Number cannot be blank")
	private String panNumber;
	@NotBlank(message = "Aadhaar Number cannot be blank")
	private String aadharNumber;
	
	@NotBlank(message = "Mobile Number cannot be blank")
	private String mobileNumber;
	private Boolean accountStatus;
	@Min(value=10000)
	private long balance;
}
