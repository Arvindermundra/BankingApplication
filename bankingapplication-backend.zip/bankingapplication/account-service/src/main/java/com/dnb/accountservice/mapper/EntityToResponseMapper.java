package com.dnb.accountservice.mapper;

import org.springframework.stereotype.Component;
import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.payload.response.AccountResponse;

@Component
public class EntityToResponseMapper {
	
	public Account accountRequestToEntity( AccountResponse accountResponse) {
		
		Account account = new Account();
		account.setAadharNumber(accountResponse.getAadharNumber());
		account.setAccountId(accountResponse.getAccountId());
		account.setAccountStatus(accountResponse.getAccountStatus());
		account.setUserId(accountResponse.getUserId());
		account.setPanNumber(accountResponse.getPanNumber());
		account.setMobileNumber(accountResponse.getMobileNumber());
		account.setAccountType(accountResponse.getAccountType());
		account.setBalance(accountResponse.getBalance());
		
		return account;
		
		
	}

}