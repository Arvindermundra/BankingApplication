package com.dnb.accountservice.service;

import java.util.Optional;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.exceptions.AccountCloseException;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.exceptions.InsufficientBalanceException;

public interface AccountService {
	
	//Create new account. 
	public Account createAccount(Account account) throws IdNotFoundException;
	//Retrieve account by its ID.
	public Optional<Account>getAccountById(String accountId) throws IdNotFoundException;
	//Retrieve all accounts.
	public Iterable<Account>getAllAccounts();
	//Retrieve account by user ID.
	public Optional<Account>getAccountByUserId(Integer userId);
	//Check if account exists by ID.
	public boolean accountExistsById(String accountId);
	//Delete account by ID.
	public boolean deleteAccountbyId(String accountId)throws IdNotFoundException;
	//Delete account by USER ID.
	public void deleteAccountByUserId(Integer userId);
	// Deposit amount into account.
	public Account depositAmount(String accountId, long balance) throws IdNotFoundException;
	// Withdraw amount from account.
	public Account withdrawAmount(String accountId, long balance) throws IdNotFoundException, InsufficientBalanceException;
	//Close account by its ID.
	public Account closeAccount(String accountId)throws IdNotFoundException,AccountCloseException;
}
